<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$servername="mysql";
$dbusername="root";
$dbpassword="Sean94!28";
$dbname="chatgpt_demo";
$conn=new mysqli($servername,$dbusername,$dbpassword,$dbname);
if($conn->connect_error) die("連線失敗: ".$conn->connect_error);
$result=$conn->query("SELECT id, username, email FROM users");
?>
<!DOCTYPE html>
<html lang="zh-TW">
<head>
<meta charset="UTF-8">
<title>後台管理 - 使用者列表</title>
<style>
body{font-family:Arial,sans-serif;padding:20px;background-color:#f4f4f4;}
table{border-collapse:collapse;width:80%;margin:auto;background-color:#fff;}
th,td{padding:10px;border:1px solid #ccc;text-align:center;}
th{background-color:#4CAF50;color:white;}
caption{caption-side:top;font-size:1.5em;margin-bottom:10px;}
</style>
</head>
<body>
<table>
<caption>註冊使用者列表</caption>
<tr><th>ID</th><th>使用者名稱</th><th>Email</th></tr>
<?php if($result->num_rows>0){while($row=$result->fetch_assoc()){echo "<tr><td>".htmlspecialchars($row['id'])."</td><td>".htmlspecialchars($row['username'])."</td><td>".htmlspecialchars($row['email'])."</td></tr>";}}else{echo "<tr><td colspan='3'>目前沒有註冊使用者</td></tr>";}$conn->close(); ?>
</table>
</body>
</html>