<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);


$username = $_POST['username'] ?? '';
$email = $_POST['email'] ?? '';
$password = password_hash($_POST['password'] ?? '', PASSWORD_DEFAULT);


$servername = "mysql";
$dbusername = "root";
$dbpassword = "Sean94!28";
$dbname = "chatgpt_demo";


$conn = new mysqli($servername, $dbusername, $dbpassword, $dbname);
if ($conn->connect_error) die("連線失敗: " . $conn->connect_error);


$check = $conn->prepare("SELECT id FROM users WHERE username=? OR email=?");
$check->bind_param("ss", $username, $email);
$check->execute();
$check->store_result();
if ($check->num_rows > 0) { $check->close(); $conn->close(); header("Location: index.html?msg=帳號或 Email 已存在"); exit; }
$check->close();


$stmt = $conn->prepare("INSERT INTO users (username, email, password) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $username, $email, $password);
if ($stmt->execute()) { $stmt->close(); $conn->close(); header("Location: index.html?msg=註冊成功！"); exit; }
else { $stmt->close(); $conn->close(); header("Location: index.html?msg=註冊失敗"); exit; }
?>